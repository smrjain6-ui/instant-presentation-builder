FONT USED IN THIS TEMPLATE :

PT Serif
      https://fonts.google.com/specimen/PT+Serif
Open Sans
      https://fonts.google.com/specimen/Open+Sans

-----------------------------------------------------

The photos used in the preview are not included.
Free font used.

Hope you Like it.
Dont Forget to rate.
Thanks.



