INTRODUCING
Thepitch - Investor Pitch Deck Power Point Template

FEATURES
- All graphics resizable and editable
- Used and recommended free web fonts
- Based on Master Slides
- 16:9 Wide Screen Ratio
- Picture Placeholder
- Just Drag and Drop!
- Easily Editable!
- Documentation File

FILES INCLUDED
- PowerPoint .PPTX file
- Documentation File

FONTS
- Nunito Sans : https://fonts.google.com/specimen/Nunito+Sans
- Montserrat : https://fonts.google.com/specimen/Montserrat

All images on the demo is just for preview purpose only and not actually included on the files

You can download images at: pexels.com and unsplash.com or you can request to: kreev.studio@gmail.com


Hope you Like it.
Thanks.