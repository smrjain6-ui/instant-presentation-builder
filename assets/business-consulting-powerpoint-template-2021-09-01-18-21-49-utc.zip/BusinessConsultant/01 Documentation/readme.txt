Author: iDoodle

Thank you for purchase!

**BUSINESS Full FAQ**

**Can I change logo and text at the bottom?

Video tutorial :  https://youtu.be/vqpACLKoRZA
** Can I edit shapes icons colors, size, place?

Video tutorial:  https://youtu.be/RNLVB4OaJzA

**What is image "Placeholder" and how works?

Video tutorial: https://youtu.be/0cHLDWnamvY

**What font is used and where can I get it?

Download font presentation on the link:

* https://fonts.google.com/specimen/Raleway
* https://fonts.google.com/?query=dosis
* https://fonts.google.com/specimen/PT+Sans

**NOTE**
All the images are display only, not included in the main download package. They are not part of the theme and NOT included in the final purchase files.

Need another Website Template & Print Products, please contact me directly via e-mail : creativewithjoy@gmail.com
doodlelys@gmail.com